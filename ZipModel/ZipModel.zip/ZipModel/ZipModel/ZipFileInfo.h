#ifndef ZIPFILEINFO_H
#define ZIPFILEINFO_H

#include "QuaZip/quazip.h"
#include "QuaZip/quazipdir.h"
#include "QuaZip/quazipfile.h"

class ZipFileInfo
{
public:
    ZipFileInfo(const QuaZipFileInfo& f, ZipFileInfo* p = 0);
    ~ZipFileInfo();
    ZipFileInfo& operator= (const ZipFileInfo& another);
    bool operator== (const ZipFileInfo& another) const;

    bool mapped;
    QuaZipFileInfo fileInfo;
    ZipFileInfo* parent;
    QList<ZipFileInfo> children;

    bool isDir() const;
    QString type() const;
    int childrenCount() const;

    QString filePath() const;
private:
};

#endif // ZIPFILEINFO_H
