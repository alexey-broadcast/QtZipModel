#ifndef FILESYSTEMMODEL_H
#define FILESYSTEMMODEL_H

#include <QAbstractItemModel>
#include <QVector>
#include "QuaZip/quazip.h"
#include "ZipFileInfo.h"
#include <QFileSystemModel>

class QFileIconProvider;
class QFileInfo;

class ZipModel : public QAbstractItemModel
{
	Q_OBJECT
public:
    explicit ZipModel(QObject *parent = 0);
    ZipModel(const QString& path, QObject *parent = 0);
    ~ZipModel();

	QModelIndex index(int row, int column, const QModelIndex &parent) const;
	QModelIndex parent(const QModelIndex &child) const;
	int rowCount(const QModelIndex &parent) const;
	int columnCount(const QModelIndex &parent) const;
    QVariant data(const QModelIndex &index, int role) const;
	QVariant headerData(int section, Qt::Orientation orientation, int role) const;
	bool canFetchMore(const QModelIndex &parent) const;
	void fetchMore(const QModelIndex &parent);
	Qt::ItemFlags flags(const QModelIndex &index) const;
    bool hasChildren(const QModelIndex &parent) const;

    inline ZipFileInfo* FileInfo(const QModelIndex& index) const
    {
        return static_cast<ZipFileInfo*>(index.internalPointer());
    }
private:
	enum Columns
	{
		RamificationColumn,
		NameColumn = RamificationColumn,
		TypeColumn,
		ModificationDateColumn,
		SizeColumn,
		ColumnCount
    };

    QuaZip* zip;
    QList<ZipFileInfo> nodes;

	void fetchRootDirectory();
    int findRow(const ZipFileInfo* nodeInfo) const;
};

#endif // FILESYSTEMMODEL_H
