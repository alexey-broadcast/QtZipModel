#ifndef MODELHELPER_H
#define MODELHELPER_H

#include <QModelIndex>
class QFtp;
class ColoredModel;
class FtpModel;
class ZipModel;
class QFileSystemModel;


class MH: public QObject
{
    Q_OBJECT
public:
    static MH *getInstance();

    static bool isDir(const QModelIndex&);
    static QString path(const QModelIndex&);
private:
    explicit MH(QObject* parent = 0);
    static MH* instance;
public slots:
    
signals:
};

#endif // MODELHELPER_H
