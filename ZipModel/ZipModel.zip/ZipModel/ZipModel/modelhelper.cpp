#include "modelhelper.h"
#include <QDebug>
#include <QFileSystemModel>
#include <QMessageBox>
#include <ZipModel.h>
#include <ZipFileInfo.h>
#include <QuaZip/JlCompress.h>
#include <QFileInfo>
#include <QFileDialog>

#define DEFAULT_MODEL "QFileSystemModel"
#define COLORED_MODEL "ColoredModel"
#define FTP_MODEL "FtpModel"
#define ZIP_MODEL "ZipModel"

MH* MH::instance = 0;

MH::MH(QObject *parent) :
    QObject(parent)
{
    
}

MH* MH::getInstance()
{
    static MH instance;
    return &instance;
}

bool MH::isDir(const QModelIndex &i)
{
    if(!i.isValid())
        return false;
    
    QString modelClass = i.model()->metaObject()->className();
    if(modelClass == COLORED_MODEL || modelClass == DEFAULT_MODEL)
    {
        const QFileSystemModel* m = qobject_cast<const QFileSystemModel*>(i.model());
        return m->isDir(i);
    }
    else if(modelClass == ZIP_MODEL)
    {
        ZipFileInfo* fileInfo = static_cast<ZipFileInfo*>(i.internalPointer());
        return fileInfo->isDir();
    }
    return false;
}


QString MH::path(const QModelIndex &index)
{
    if(!index.isValid())
        return "";
    QString modelClass = index.model()->metaObject()->className();
    if(modelClass == COLORED_MODEL || modelClass == DEFAULT_MODEL)
    {
        const QFileSystemModel* m = qobject_cast<const QFileSystemModel*>(index.model());
        QString path = m->filePath(index);
        if(m->isDir(index))
            path = path + '/';
        //qDebug() << "MH::path: " << path;
        return path;
    }
    else
    {
        QStringList path;
        QModelIndex i = index;
        if(i.data() == "..")
            i = i.parent().parent();
        for(; i.isValid(); i = i.parent())
            path << i.data().toString();

        QString ret;
        if(modelClass == ZIP_MODEL)
            for(int i = path.count() - 1; i >= 0; --i)
                ret += path[i];
        else if(modelClass == FTP_MODEL)
        {
            for(int i = path.count() - 1; i > 0; --i)
                ret += path[i] + '/';
            ret += path[0];
            if(isDir(index))
                ret += '/';
        }
        return ret;
    }
}
